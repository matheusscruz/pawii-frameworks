/*app.controller("meuControle", function($scope) {
    $scope.nome = "Polastri";
    $scope.sobrenome = "Danilo";
});*/