var conexao = require('./bdConectaAgenda');

conexao.connect(function(err) {
    if (err) throw err;
    console.log('Conexão estabelecida com sucesso!');

    var operacao = "INSERT INTO pessoa (nome, telefone) VALUES ?";

    var pessoas = [
        ['Maria', '(21)99999-9999'],
        ['Xesquedele', '(21)99999-9999'],
        ['Brelele', '(21)99999-9999'],
        ['Dale Dele', '(21)99999-9999'],
        ['Clodoaldo', '(21)99999-9999'],
        ['Doly', '(21)99999-9999'],
        ['Xesquebrele', '(21)99999-9999']
    ];

    conexao.query(operacao, [pessoas], function(err) {
        if (err) throw err;
        console.log('Pessoas incluídas com sucesso!');
    });
});