var mysql = require('mysql'); //Criar o banco de dados. OBS: Checar no mysql SHOW DATABASES;
var conexao = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "123456"
});

conexao.connect(function(err) {
    if (err) throw err;
    console.log('Connection successful!');

    conexao.query("CREATE DATABASE Agenda", function() {
        if (err) throw err;
        console.log('Database created sucess!');
    });
});