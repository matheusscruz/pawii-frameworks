var mysql = require('mysql'); //Subir o banco 'agenda'

var conexao = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"123456",
    database: "agenda"
});
console.log('Success!');

module.exports = conexao;