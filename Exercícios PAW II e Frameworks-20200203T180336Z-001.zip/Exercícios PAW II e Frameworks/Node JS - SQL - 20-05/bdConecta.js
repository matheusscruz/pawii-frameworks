var mysql = require('mysql'); //Estabelecer conexão
var conexao = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "123456"
});

conexao.connect(function(err) {
    if (err) throw err;
    console.log('Connection successful');
});

module.exports = conexao;