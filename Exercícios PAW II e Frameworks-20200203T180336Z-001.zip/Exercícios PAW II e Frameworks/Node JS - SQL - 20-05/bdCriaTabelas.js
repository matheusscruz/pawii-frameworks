var conexao = require('./bdConectaAgenda.js'); //Criação de tabela dentro do banco 'agenda'.

conexao.connect(function(err) {
    if (err) throw err;
    console.log('Conexão estabelecida com sucesso!');

    var op = "CREATE TABLE pessoa(id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(30), telefone VARCHAR(15))";
        conexao.query(op, function(err) {
            if (err) throw err;
            console.log('Tabela criada com sucesso!');
    }); 
});

module.exports = conexao;