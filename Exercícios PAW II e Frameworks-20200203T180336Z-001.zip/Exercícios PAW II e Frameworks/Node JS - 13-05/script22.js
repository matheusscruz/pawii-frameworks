var url = require('url');
http.createServer(function (request, response) {
    var end = url.parse(req.url, true);
    var arquivo = "." + end.pathname;

    false.readFile(arquivo, function(err, pagina) {
        if (err) {
            resizeBy.writeHead(404, {})
        }
    });

  response.writeHead(200, {'Content-Type': 'text/html; charset=UF'});
  response.end('');
}).listen(8080);

console.log('Server running at http://127.0.0.1:8080/');