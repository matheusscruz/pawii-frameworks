var http = require('http');
var url = require('url');
var end = 'http://localhost:8080/data.html?dia=17&mes=3&ano=2003';
var dados = url.parse(end, true);


http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html; charset=UTF-8'});
    res.write('Host: ' + dados.host + '<br>');
    res.write('Caminho: ' + dados.pathname + '<br>');
    res.write('Argumentos: ' + dados.search + '<br>');
    var d = dados.query;
    res.write('Dia: ' + d.dia + '<br>');
    res.write('Mês: ' + d.mes + '<br>');
    res.write('Ano: ' + d.ano);

    res.end();
}).listen(8080);

console.log('Server running at http://127.0.0.1:8080/');