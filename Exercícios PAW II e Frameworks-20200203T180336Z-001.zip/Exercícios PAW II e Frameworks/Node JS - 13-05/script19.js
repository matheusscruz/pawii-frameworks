const fs = require('fs');

fs.unlink('ArquivoNovo.txt', function(err) {
if (err) throw err;
});

console.log('Meu mano, o arquivo foi excluido aperta CTRL + C para fechar o prompt.');