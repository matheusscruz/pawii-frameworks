const fs = require('fs');

fs.rename('NovoArquivo.txt', 'arquivo6.txt', function(err) {
if (err) throw err;
});

console.log('Arquivo renomeado com sucesso!');