const fs = require('fs');
const texto = 'Programar é construir o futuro!';

fs.writeFile('arquivo3.txt', texto, function(err) {
if (err) throw err;
});

console.log('Arquivo gravado com sucesso!');