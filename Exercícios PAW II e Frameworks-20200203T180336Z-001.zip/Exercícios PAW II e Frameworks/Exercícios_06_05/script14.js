const fs = require ('fs');

fs.writeFile ('arquivo2.txt', 'Desenvolvimento Web - JavaScript e Node JS', function(err) {
    if (err) throw err;
});
console.log('Meu Deus funcionou cara!');