const http = require ('http');
const fs = require ('fs');

http.createServer(function (req, res) {
fs.readFile('pagina12.html', function(err, dados) {
res.writeHead(200, {'Content-Type': 'text/html'});
res.write(dados);
res.end();
});
}).listen(8080);

console.log('Servidor startado na porta 8080. Pressione CTRL + C para encerrar.');