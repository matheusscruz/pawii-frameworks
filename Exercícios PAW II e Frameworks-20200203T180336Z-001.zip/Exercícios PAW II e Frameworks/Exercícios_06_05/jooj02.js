const http = require('http');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    res.write('<htm>');
    res.write('<head>');
    res.write('<title>Aula de Node</title>');
    res.write('</head>');
    res.write('<body>');
    res.write('<h2>Desenvolvimento de Aplicações Web (Node.js)</h2>');
    res.write('</body>');
    res.write('</html>');
    res.end();
}).listen(8080);


