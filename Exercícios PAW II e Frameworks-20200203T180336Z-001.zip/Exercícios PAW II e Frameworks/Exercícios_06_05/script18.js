const http = require('http');
const url = require('url');
const fs = require ('fs');

http.createServer(function (req, res) {
    var dados = url.parse(req.url, true).query;
    var nome = dados.nome;
    var sobrenome = dados.sobrenome;

    var nc = nome + ' ' + sobrenome;
    fs.appendFile('listaNome.txt', nc + '\r\n', function(err) {
    if (err) throw err;
    });

    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write('Nome: ' + nome + '<br>');
    res.write('Sobrenome: ' + sobrenome);
    res.end();
}).listen(8080);

console.log('Servidor iniciado na porta 8080, pressione CTRL + C para sair.');