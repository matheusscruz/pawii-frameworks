var fs = require('fs');
// primeira versão
//fs.appendFile('arquivo5.txt', 'Programação Web\r\n', function(err) {
//	if (err) throw err;/
//});


// versão 1.1//
//fs.appendFile('arquivo5.txt', 'Programação e Desenvolvimento Web\r\n', function(err) {
//	if (err) throw err;
//});


//versão 1.2
fs.appendFile('arquivo5.txt', 'Desenvolvimento Web II\r\n', function(err) {
if (err) throw err;
});



console.log('Dados adicionados com sucesso!');