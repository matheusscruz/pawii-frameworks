const http = require('http');
var nome = "Matheus Cruz";
var idade = 20;
var peso = 80.50;
var altura = 1.75;
var sexo = 'M';

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    res.write('<htm>');
    res.write('<head>');
    res.write('<title>Clínica</title>');
    res.write('</head>');
    res.write('<body>');
    res.write('<h2>Dados do cliente:</h2>');
    res.write('<p>');
    res.write('Nome: ' + nome + '<br>');
    res.write('Idade: ' + idade + '<br>');
    res.write('Peso: ' + peso + '<br>');
    res.write('Altura: ' + altura + '<br>');
    res.write('Sexo: ' + sexo + '<br>');
    res.write('</body>');
    res.write('</html>');
    res.end();
}).listen(8080);

console.log("Servidor iniciado em localhost:8080. Pressione CTRL + C para sair.");

