const http = require('http');

http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type':'text/plain; charset=utf-8'});
    res.write('Porra Werner, até quando...?');
    res.write('AIDOEU');
    res.end('Servidor aberto em localhost: 8080. Pressione CTRL C para encerrar.');
}).listen(8080);

console.log('Servidor aberto em localhost:8080. Pressione CTRL + C para encerrar.');
