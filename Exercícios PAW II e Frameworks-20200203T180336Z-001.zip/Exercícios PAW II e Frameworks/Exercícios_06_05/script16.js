// incluir o modulo http - trabalhar com servidor//
const http = require('http'); 
// incluir modulo - trabalhar com arquivos//
const fs = require('fs');
// criação do servidor //
http.createServer(function(req, res) {
//tudo que tiver aqui vai ser executado sempre que o cliente acessar a porta 8080//
fs.readFile('pagina12.html', function(err, dados) {
// err = erro
// connfigurar o cabeçalho http//
res.writeHead(200, {'Content-Type': 'text/html'});
res.write(dados);
// passar o que está na página 12 para o arquivo4.txt//
fs.writeFile('arquivo4.txt', dados, function(err) {
if (err) throw err;
});   

res.end();

});

}).listen(8080);	
console.log('Servidor iniciado na porta 8080. Pressione Ctrl + C para encerrar');