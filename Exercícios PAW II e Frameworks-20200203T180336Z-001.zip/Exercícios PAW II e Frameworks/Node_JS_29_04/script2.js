var http = require('http');
var d = require('./modulo01');
http.createServer(function (request, response) {
  response.writeHead(200, {'Content-Type': 'text/html;charset=UTF-8'});

  response.write('Hoje é ' + d.retornarDia() + '/' + d.retornarMes() + '/' + d.retornarAno());
  response.end("<br>TEM QUE TER MENOR</br>");

}).listen(8080);

console.log('Server iniciado na porta 8080. Pressione CTRL + C para encerrar.');