data = new Date;

exports.retornarData = function() {
    return Date();
};

exports.retornarDia = function() {
    return data.getDate();
}

exports.retornarMes = function() {
    return data.getMonth()+1;
}

exports.retornarAno = function() {
    return data.getFullYear();
}
