function validarNome(nome) {
    if (nome == ""){
        window.alert("O nome não pode estar vazio!");
        window.document.getElementById('nome').focus();
    }
    else if (nome.length <= 10) {
        window.alert("O campo nome deve ter mais de 10 caracteres!");
        document.getElementById('nome').focus();
    }
}
function validarSenha(senha) {
    var email = getElementById('email').value;
    var usuario = email.substring(0, email.indexOf('@'));
    window.alert(usuario);
    if (senha.length < 4) {
        window.alert("O campo senha deve ter mais de 4 caracteres!");
        document.getElementById('senha').focus();
    }
    else if (senha == usuario) {
        window.alert("O campo senha não pode ser igual ao usuário do email!");
        document.getElementById('senha').focus();
   }
}
function enviarDados() {
    var senha = document.getElementById('senha').value;
    var confsenha = document.getElementById('confsenha').value;

    if (senha == confsenha)
    document.getElementById('frm').onsubmit();
    else
    window.alert("As senhas digitadas são diferentes!");
}